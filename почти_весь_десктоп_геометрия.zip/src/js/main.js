/* libs */

//= libs/jquery-3.3.1.min.js
///= libs/jquery.fancybox.min.js
//= libs/slick.min.js
//= libs/vanillaTextMask.js
//= libs/ion.rangeSlider.min.js
//= libs/select2.min.js
//= libs/select2-ru.js
//= libs/simplebar.min.js

/* my scripts */

//= partials/components.js
//= partials/header.js
//= partials/main.js
